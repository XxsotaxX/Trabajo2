﻿using System;

namespace AlumnosBOL
{
    public class Asignatura
    {
        public int CodigoAsignatura { get; set; }
        public string NombreAsignatura { get; set; }
        public int Creditos { get; set; }
    }
}